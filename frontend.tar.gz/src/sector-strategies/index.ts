// Exporta todas as estratégias de um único local

export * from './agro.strategy';
// A linha abaixo é a que disponibiliza 'ServicesStrategy'
export * from './services.strategy'; 
export * from './construction.strategy';
export * from './FreightStrategy'; // <-- ADICIONE ESTA LINHA
